package com.cg.paymentwalletapp.dao;

import com.cg.paymentwalletapp.dto.Wallet;
import com.cg.paymentwalletapp.exception.PaymentException;

public interface IPaymentDao {
	public void createAccount(Wallet wallet);

	public double showBalance(String userId);

	public void deposit(String userId, double amount);

	public void withdraw(String userId, double amount);

	public boolean fundTransfer(String userIdSender, String userIdReceiver, double amount) throws PaymentException;

	public String printTransactions(String userId);

	public Wallet login(String id, String password) throws PaymentException;

}
