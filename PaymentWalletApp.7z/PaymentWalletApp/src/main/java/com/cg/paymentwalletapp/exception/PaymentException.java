package com.cg.paymentwalletapp.exception;

@SuppressWarnings("serial")
public class PaymentException extends Exception{
	public PaymentException() {
		super();
	}

	public PaymentException(String message) {
		System.out.println(message);
	}

}
