package com.cg.paymentwalletapp.service;

import com.cg.paymentwalletapp.dao.IPaymentDao;
import com.cg.paymentwalletapp.dao.PaymentDaoImpl;
import com.cg.paymentwalletapp.dto.Wallet;
import com.cg.paymentwalletapp.exception.IPaymentException;
import com.cg.paymentwalletapp.exception.PaymentException;

public class PaymentServiceImpl implements IPaymentService{
	
	IPaymentDao dao = new PaymentDaoImpl();

	public boolean createAccount(Wallet wallet) {
		boolean result = false;
		dao.createAccount(wallet);
		return result;
		
	}

	public double showBalance(String userId) {
		
		return dao.showBalance(userId);
	}

	public boolean deposit(String userId, double amount) {
		boolean result = false;
		if (amount > 0) {
			dao.deposit(userId, amount);
			result = true;
		}

		return result;
		
	}

	public boolean withdraw(String userId, double amount) {
		boolean result = false;
		if (dao.showBalance(userId) >= amount) {
			dao.withdraw(userId, amount);
			result = true;
		}

		return result;
		
	}

	public boolean fundTransfer(String userIdSender, String userIdReceiver, double amount) throws PaymentException {
		boolean result = false;
		if (dao.showBalance(userIdSender) >= amount) {
			if (dao.fundTransfer(userIdSender, userIdReceiver, amount)) {
				result = true;	
			}
		}
		return result;
	}

	public String printTransactions(String phNumber) {
		return null;
	}

	public boolean validateDetails(Wallet wallet) throws PaymentException {
		boolean result = false;
		String regex = "[A-Z]{1}[a-z]+";
		String regex2 = "[0-9]{10}";
		String regex3 = "[a-z0-9_.]{1,}@[a-z]{1,10}.com";
		if (wallet.getName().matches(regex)) {
			if (wallet.getPhNumber().matches(regex2)) {
				if (wallet.getEmailId().matches(regex3)) {
					result = true;

				} else
					throw new PaymentException(IPaymentException.ERROR3);
			} else
				throw new PaymentException(IPaymentException.ERROR2);
		} else
			throw new PaymentException(IPaymentException.ERROR1);
		return result;
		
	}

	public Wallet login(String id, String password) throws PaymentException {
		return dao.login(id, password);
	}

	
}
