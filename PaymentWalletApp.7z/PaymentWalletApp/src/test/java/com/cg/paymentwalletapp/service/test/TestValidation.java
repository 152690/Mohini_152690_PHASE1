package com.cg.paymentwalletapp.service.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.paymentwalletapp.dao.IPaymentDao;
import com.cg.paymentwalletapp.dao.PaymentDaoImpl;
import com.cg.paymentwalletapp.dto.Wallet;
import com.cg.paymentwalletapp.exception.PaymentException;
import com.cg.paymentwalletapp.service.IPaymentService;
import com.cg.paymentwalletapp.service.PaymentServiceImpl;


public class TestValidation {
	IPaymentService service=new PaymentServiceImpl();
	IPaymentDao dao=new PaymentDaoImpl();
		@Test
		public void CheckForZeroDeposittest() {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("9595959595");
			dao.createAccount(wallet);
			condition=service.deposit("9595959595", 0.0);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidDepositAmount() {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("9595959595");
			dao.createAccount(wallet);
			condition=service.deposit("9595959595", 500);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("absdy5t5q6");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			service.validateDetails(wallet);
		}
		
		@Test
		public void CheckForValidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("959595");
			wallet.setEmailId("mohini@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("4g53jkbf");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}

}
